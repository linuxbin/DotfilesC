# Installation
### Download and change folder
```
cd ~
git clone https://github.com/flipsidecreations/dotfiles.git

cd dotfiles
```
### Run intstall
```
./install.sh
```

